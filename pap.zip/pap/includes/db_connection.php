<?php
include_once 'funcoes.php';

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Ativa o modo de exceção do MySQLi
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try {
    // Tenta estabelecer a conexão
    $banco = new mysqli('localhost', 'i243443', 'i243443', 'i243443_pap');
    $banco->set_charset("utf8");

    echo "<p style='color: green; font-weight: bold;'>✅ Conexão com o banco de dados estabelecida com sucesso!</p>";
    // NOTA: Não há mensagem de sucesso aqui.
} catch (mysqli_sql_exception $e) {
    // Se a conexão falhar, exibe o erro e PÁRA O SCRIPT.
    exibirErro($e->getMessage());
    exit();
}
// IMPORTANTE:
// NÃO execute $banco->query() aqui.
// Deixe a variável $banco "viva" para o index.php usar.
?>
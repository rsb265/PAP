<?php
function exibirErro($mensagem) {
    echo "<div style='border: 1px solid red; padding: 10px; background-color: #fdd; color: #900;'>";
    echo "<strong>Erro:</strong> " . htmlspecialchars($mensagem);
    echo "</div>";
} 
?>